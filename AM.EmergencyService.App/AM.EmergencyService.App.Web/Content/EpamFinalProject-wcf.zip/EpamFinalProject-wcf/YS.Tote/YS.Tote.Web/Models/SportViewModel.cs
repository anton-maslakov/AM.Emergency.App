﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace YS.Tote.Web.Models
{
    public class SportViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Поле обязательно для заполнения")]
        [Display(Name = "Название спорта")]
        [StringLength(25, ErrorMessage = "Ошибка длины", MinimumLength = 3)]
        [DataType(DataType.Text)]
        public string Sport { get; set; }
    }
}