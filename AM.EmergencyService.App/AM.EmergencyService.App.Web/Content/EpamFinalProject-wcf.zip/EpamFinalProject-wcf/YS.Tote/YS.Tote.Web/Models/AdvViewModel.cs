﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace YS.Tote.Web.Models
{
    public class AdvViewModel
    {
        public int Id { get; set; }

        public string Message { get; set; }
    }
}