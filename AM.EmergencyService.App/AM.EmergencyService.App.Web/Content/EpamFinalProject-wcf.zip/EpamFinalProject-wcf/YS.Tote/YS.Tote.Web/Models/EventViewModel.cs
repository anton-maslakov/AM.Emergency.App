﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace YS.Tote.Web.Models
{
    public class EventViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Поле обязательно для заполнения")]
        [Display(Name = "Дата события")]
        [DataType(DataType.Date)]
        public DateTime EventDate { get; set; }

        [Required(ErrorMessage = "Поле обязательно для заполнения")]
        [Display(Name = "Первая команда")]
        public int FirstTeamId { get; set; }

        [Required(ErrorMessage = "Поле обязательно для заполнения")]
        [Display(Name = "Вторая команда")]
        public int SecondTeamId { get; set; }

        [Display(Name = "Статус события")]
        public string IsActualEvent { get; set; }

        [Required(ErrorMessage = "Поле обязательно для заполнения")]
        [Display(Name = "Название события")]
        [DataType(DataType.Text)]
        [StringLength(50, ErrorMessage = "Ошибка длины", MinimumLength = 3)]
        public string EventName { get; set; }

        [Required(ErrorMessage = "Поле обязательно для заполнения")]
        [Display(Name = "Вид спорта")]
        [DataType(DataType.Text)]
        public string KindOfSport { get; set; }
    }
}