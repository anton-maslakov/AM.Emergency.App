﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using YS.Tote.Common.EntityModels;
using YS.Tote.Web.Models;

namespace YS.Tote.Web.Helpers
{
    public static class Parser
    {
        public static IReadOnlyCollection<EventViewModel> GetParseCollection(IEnumerable<EventModel> list)
        {
            List<EventViewModel> parsedList = new List<EventViewModel>();

            foreach (var item in list)
            {
                parsedList.Add(new EventViewModel
                {
                    Id = item.Id,
                    EventDate = item.EventDate,
                    EventName = item.EventName,
                    FirstTeamId = item.FirstTeamId,
                    SecondTeamId = item.SecondTeamId,
                    IsActualEvent = item.EventStatus,
                    KindOfSport = item.KindOfSport
                });
            }

            return parsedList;
        }

        public static IEnumerable<SportViewModel> GetParseCollection(IEnumerable<SportModel> list)
        {
            List<SportViewModel> parsedList = new List<SportViewModel>();

            foreach (var item in list)
            {
                parsedList.Add(new SportViewModel
                {
                    Id = item.Id,
                    Sport = item.SportName
                });
            }

            return parsedList;
        }

        public static EventViewModel GetParseModel(EventModel model)
        {
            return new EventViewModel()
            {
                Id = model.Id,
                EventDate = model.EventDate,
                EventName = model.EventName,
                FirstTeamId = model.FirstTeamId,
                IsActualEvent = model.EventStatus,
                KindOfSport = model.KindOfSport,
                SecondTeamId = model.SecondTeamId
            };
        }

        public static SportViewModel GetParseModel(SportModel model)
        {
            return new SportViewModel()
            {
                Id = model.Id,
                Sport = model.SportName
            };
        }

        public static EventModel GetParseViewModel(EventViewModel viewModel)
        {
            return new EventModel()
            {
                Id = viewModel.Id,
                EventDate = viewModel.EventDate,
                EventName = viewModel.EventName,
                FirstTeamId = viewModel.FirstTeamId,
                EventStatus = viewModel.IsActualEvent,
                KindOfSport = viewModel.KindOfSport,
                SecondTeamId = viewModel.SecondTeamId
            };
        }

        public static SportModel GetParseViewModel(SportViewModel viewModel)
        {
            return new SportModel()
            {
                SportName = viewModel.Sport
            };
        }
    }
}