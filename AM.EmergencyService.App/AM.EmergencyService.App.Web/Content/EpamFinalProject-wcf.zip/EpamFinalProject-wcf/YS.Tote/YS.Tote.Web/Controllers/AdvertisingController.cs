﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using YS.Tote.BusinessLogic.Abstracts;
using YS.Tote.Common.EntityModels;
using YS.Tote.Web.Models;

namespace YS.Tote.Web.Controllers
{
    public class AdvertisingController : Controller
    {
        private readonly IAdvertisingService _advService;

        public AdvertisingController(IAdvertisingService advertisingService)
        {
            _advService = advertisingService;
        }

        // GET: Advertising
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(AdvViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                _advService.Create(new AdvModel { Message = viewModel.Message });

                return RedirectToAction("Index", "Advertising");
            }

            return View(viewModel);
        }
    }
}