﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using YS.Tote.BusinessLogic.Abstracts;
using YS.Tote.Common.EntityModels;
using YS.Tote.Web.Helpers;
using YS.Tote.Web.Models;

namespace YS.Tote.Web.Controllers
{
    public class SportController : Controller
    {
        private readonly ISportService _sportService;

        public SportController(ISportService sportService)
        {
            _sportService = sportService;
        }

        // GET: Sport
        public ActionResult Index()
        {
            IEnumerable<SportModel> list = _sportService.ListOfSports();

            var viewList = Parser.GetParseCollection(list);

            return View(viewList);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(SportViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                var model = Parser.GetParseViewModel(viewModel);

                _sportService.Create(model);

                return RedirectToAction("Index", "Sport");
            }

            return View(viewModel);
        }

        public ActionResult Edit(int? id)
        {
            var model = _sportService.SelectById(id);

            var viewModel = Parser.GetParseModel(model);

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(SportViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                var model = Parser.GetParseViewModel(viewModel);

                _sportService.Update(model);

                return RedirectToAction("ListOfEvents", "Event");
            }

            return View(viewModel);
        }

        public ActionResult Details(int? id)
        {
            var model = _sportService.SelectById(id);

            var viewModel = Parser.GetParseModel(model);

            return View(viewModel);
        }

        public ActionResult Delete(int? id)
        {
            var model = _sportService.SelectById(id);

            var viewModel = Parser.GetParseModel(model);

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(SportViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                _sportService.Delete(viewModel.Id);

                return RedirectToAction("ListOfEvents", "Event");
            }

            return View(viewModel);
        }

        public ActionResult Navigation()
        {
            ViewBag.ListOfSportNames = _sportService.ListOfSportNames();

            return PartialView();
        }
    }
}