﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using YS.Tote.BusinessLogic.Abstracts;
using YS.Tote.Common.Loggers;
using YS.Tote.Web.Helpers;
using YS.Tote.Web.Models;

namespace YS.Tote.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly IAdvertisingService _advService;

        public HomeController(IAdvertisingService advertisingService)
        {
            _advService = advertisingService;
        }

        // GET: Home
        public ActionResult Index()
        {
            var model = _advService.SelectAdvertising(1);

            var viewModel = new AdvViewModel() { Id = model.Id, Message = model.Message };

            return View(viewModel);
        }
    }
}