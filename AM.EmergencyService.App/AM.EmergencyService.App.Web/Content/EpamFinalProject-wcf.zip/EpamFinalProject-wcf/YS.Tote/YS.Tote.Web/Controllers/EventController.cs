﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using YS.Tote.BusinessLogic.Abstracts;
using YS.Tote.Web.Helpers;
using YS.Tote.Web.Models;

namespace YS.Tote.Web.Controllers
{
    public class EventController : Controller
    {
        private readonly ISportService _sportService;

        private readonly IEventService _eventService;

        public EventController(ISportService sportService, IEventService eventService)
        {
            _sportService = sportService;
            _eventService = eventService;
        }

        // GET: Event
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Create()
        {
            ViewBag.ListOfSportNames = _sportService.ListOfSportNames();

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(EventViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                var model = Parser.GetParseViewModel(viewModel);

                _eventService.Create(model);

                return RedirectToAction("ListOfEvents", "Event");
            }

            ViewBag.ListOfSportNames = _sportService.ListOfSportNames();

            return View(viewModel);
        }

        public ActionResult Edit(int? id)
        {
            var viewModel = Parser.GetParseModel(_eventService.SelectEventById(id));

            ViewBag.ListOfSportNames = _sportService.ListOfSportNames();

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(EventViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                var model = Parser.GetParseViewModel(viewModel);

                _eventService.Update(model);

                return RedirectToAction("ListOfEvents", "Event");
            }

            ViewBag.ListOfSportNames = _sportService.ListOfSportNames();

            return View(viewModel);
        }

        public ActionResult Details(int? id)
        {
            var model = _eventService.SelectEventById(id);

            var viewModel = Parser.GetParseModel(model);

            return View(viewModel);
        }

        public ActionResult Delete(int? id)
        {
            var model = _eventService.SelectEventById(id);

            var viewModel = Parser.GetParseModel(model);

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(EventViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                _eventService.Delete(viewModel.Id);

                return RedirectToAction("ListOfEvents", "Event");
            }

            return View(viewModel);
        }

        public ActionResult ListOfEvents()
        {
            return View();
        }

        public ActionResult TableData(string sport)
        {
            IEnumerable<EventViewModel> events = Parser.GetParseCollection(_eventService.ListOfEvents());

            if (sport != null)
            {
                var sortedEvents = events.Where(m => m.KindOfSport == sport);

                return PartialView(sortedEvents);
            }

            return PartialView(events);
        }
    }
}