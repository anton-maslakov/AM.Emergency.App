﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.BusinessLogic.Abstracts;
using YS.Tote.Common.EntityModels;
using YS.Tote.DataAccess.Abstract;

namespace YS.Tote.BusinessLogic.Services
{
    public class TeamService : ITeamService
    {
        private readonly ITeamComponent _teamComponent;

        public TeamService(ITeamComponent teamComponent)
        {
            _teamComponent = teamComponent;
        }

        public void Create(TeamModel model)
        {
            _teamComponent.Create(model);
        }

        public void Delete(int? id)
        {
            _teamComponent.Delete(id);
        }

        public IEnumerable<TeamModel> SelectAll()
        {
            var list = _teamComponent.SelectAll();

            return list;
        }

        public TeamModel SelectByCountry(string countryName)
        {
            var model = _teamComponent.SelectByCountry(countryName);

            return model;
        }

        public TeamModel SelectById(int? id)
        {
            var model = _teamComponent.SelectById(id);

            return model;
        }

        public TeamModel SelectByName(string teamName)
        {
            var model = _teamComponent.SelectByName(teamName);

            return model;
        }

        public void Update(TeamModel model)
        {
            _teamComponent.Update(model);
        }
    }
}
