﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.BusinessLogic.Abstracts;
using YS.Tote.Common.EntityModels;
using YS.Tote.DataAccess.Abstract;

namespace YS.Tote.BusinessLogic.Services
{
    public class AdvertisingService : IAdvertisingService
    {
        private readonly IAdvertisingComponent _advComponent;

        public AdvertisingService(IAdvertisingComponent advComponent)
        {
            _advComponent = advComponent;
        }

        public void Create(AdvModel model)
        {
            _advComponent.Create(model);
        }

        public AdvModel SelectAdvertising(int? id)
        {
            var model = _advComponent.SelectAdvertising(id);

            return model;
        }
    }
}
