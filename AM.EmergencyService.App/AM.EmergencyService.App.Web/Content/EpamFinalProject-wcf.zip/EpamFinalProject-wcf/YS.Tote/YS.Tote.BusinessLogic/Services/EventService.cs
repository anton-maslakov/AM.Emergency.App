﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.BusinessLogic.Abstracts;
using YS.Tote.Common.EntityModels;
using YS.Tote.DataAccess.Abstract;

namespace YS.Tote.BusinessLogic.Services
{
    public class EventService : IEventService
    {
        private readonly IEventComponent _eventComponent;

        public EventService(IEventComponent eventComponent)
        {
            _eventComponent = eventComponent;
        }

        public void Create(EventModel model)
        {
            _eventComponent.Create(model);
        }

        public void Delete(int? id)
        {
            _eventComponent.Delete(id);
        }

        public IEnumerable<EventModel> ListOfEvents()
        {
            IEnumerable<EventModel> list = _eventComponent.SelectAll();

            return list;
        }

        public EventModel SelectEventByActual(string eventStatus)
        {
            var model = _eventComponent.SelectEventByStatus(eventStatus);

            return model;
        }

        public EventModel SelectEventByDate(DateTime eventDate)
        {
            var model = _eventComponent.SelectEventByDate(eventDate);

            return model;
        }

        public EventModel SelectEventById(int? id)
        {
            var model = _eventComponent.SelectById(id);

            return model;
        }

        public EventModel SelectEventByKindOfSport(string kindOfSport)
        {
            var model = _eventComponent.SelectEventByKindOfSport(kindOfSport);

            return model;
        }

        public EventModel SelectEventByName(string eventName)
        {
            var model = _eventComponent.SelectByName(eventName);

            return model;
        }

        public void Update(EventModel model)
        {
            _eventComponent.Update(model);
        }
    }
}
