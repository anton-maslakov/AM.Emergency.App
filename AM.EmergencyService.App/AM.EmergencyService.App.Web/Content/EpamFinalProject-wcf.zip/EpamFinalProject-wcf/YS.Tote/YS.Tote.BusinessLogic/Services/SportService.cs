﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.BusinessLogic.Abstracts;
using YS.Tote.Common.EntityModels;
using YS.Tote.DataAccess.Abstract;

namespace YS.Tote.BusinessLogic.Services
{
    public class SportService : ISportService
    {
        private readonly ISportComponent _sportComponent;

        private List<string> _names = new List<string>();

        public SportService(ISportComponent sportComponent)
        {
            _sportComponent = sportComponent;
        }

        public void Create(SportModel model)
        {
            _sportComponent.Create(model);
        }

        public void Delete(int? id)
        {
            _sportComponent.Delete(id);
        }

        public IEnumerable<string> ListOfSportNames()
        {
            var list = _sportComponent.SelectAll();

            foreach (var item in list)
            {
                _names.Add(item.SportName);
            }

            return _names;
        }

        public IEnumerable<SportModel> ListOfSports()
        {
            var list = _sportComponent.SelectAll();

            return list;
        }

        public SportModel SelectById(int? id)
        {
            var model = _sportComponent.SelectById(id);

            return model;
        }

        public SportModel SelectByName(string sport)
        {
            var model = _sportComponent.SelectByName(sport);

            return model;
        }

        public void Update(SportModel model)
        {
            _sportComponent.Update(model);
        }
    }
}
