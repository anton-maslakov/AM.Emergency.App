﻿using StructureMap.Configuration.DSL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.BusinessLogic.Abstracts;
using YS.Tote.BusinessLogic.Services;

namespace YS.Tote.BusinessLogic.Dependency
{
    public class BusinessRegistry : Registry
    {
        public BusinessRegistry()
        {
            For<IAdvertisingService>().Use<AdvertisingService>();
            For<IEventService>().Use<EventService>();
            For<ISportService>().Use<SportService>();
            For<ITeamService>().Use<TeamService>();
        }
    }
}
