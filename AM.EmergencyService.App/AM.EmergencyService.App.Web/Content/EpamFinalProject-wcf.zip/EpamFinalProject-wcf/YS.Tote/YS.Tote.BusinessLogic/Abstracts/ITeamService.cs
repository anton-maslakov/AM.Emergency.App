﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.Common.EntityModels;

namespace YS.Tote.BusinessLogic.Abstracts
{
    public interface ITeamService
    {
        void Create(TeamModel contract);

        void Update(TeamModel contract);

        void Delete(int? id);

        TeamModel SelectById(int? id);

        IEnumerable<TeamModel> SelectAll();

        TeamModel SelectByName(string teamName);

        TeamModel SelectByCountry(string countryName);
    }
}
