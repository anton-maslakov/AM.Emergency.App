﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.Common.EntityModels;

namespace YS.Tote.BusinessLogic.Abstracts
{
    public interface IEventService
    {
        void Create(EventModel model);
        void Update(EventModel model);
        void Delete(int? id);
        IEnumerable<EventModel> ListOfEvents();
        EventModel SelectEventById(int? id);
        EventModel SelectEventByDate(DateTime eventDate);
        EventModel SelectEventByActual(string eventStatus);
        EventModel SelectEventByName(string eventName);
        EventModel SelectEventByKindOfSport(string kindOfSport);
    }
}
