﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.Common.EntityModels;

namespace YS.Tote.BusinessLogic.Abstracts
{
    public interface ISportService
    {
        void Create(SportModel model);

        void Update(SportModel model);

        void Delete(int? id);

        SportModel SelectById(int? id);

        SportModel SelectByName(string sport);

        IEnumerable<SportModel> ListOfSports();

        IEnumerable<string> ListOfSportNames();
    }
}
