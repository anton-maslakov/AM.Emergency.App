﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.Common.EntityModels;

namespace YS.Tote.BusinessLogic.Abstracts
{
    public interface IAdvertisingService
    {
        AdvModel SelectAdvertising(int? id);

        void Create(AdvModel model);
    }
}
