﻿using StructureMap.Configuration.DSL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace YS.Tote.WCF.Dependency
{
    public class WCFRegistry : Registry
    {
        public WCFRegistry()
        {
            For<IAdvertisingService>().Use<AdvertisingService>();
        }
    }
}