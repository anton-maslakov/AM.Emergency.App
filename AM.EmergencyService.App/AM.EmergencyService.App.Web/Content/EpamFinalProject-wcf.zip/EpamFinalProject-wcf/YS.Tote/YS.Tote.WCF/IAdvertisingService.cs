﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace YS.Tote.WCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IAdvertisingService" in both code and config file together.
    [ServiceContract]
    public interface IAdvertisingService
    {
        [OperationContract]
        AdvContract GetAdvertising(int? id);

        [OperationContract]
        void SetAdvertising(AdvContract contract);
    }
}
