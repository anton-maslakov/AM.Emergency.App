﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Xml.Linq;

namespace YS.Tote.WCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "AdvertisingService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select AdvertisingService.svc or AdvertisingService.svc.cs at the Solution Explorer and start debugging.
    public class AdvertisingService : IAdvertisingService
    {
        public AdvContract GetAdvertising(int? id)
        {
            var file = ConfigurationManager.AppSettings["fileAdv"];

            var document = XDocument.Load(file);

            var element = document.Descendants("AdvModel").FirstOrDefault(m => m.Attribute("Id").Value == id.ToString());

            var model = new AdvContract() { Id = int.Parse(element.Attribute("Id").Value), Message = element.Element("Message").Value };

            return model;
        }

        public void SetAdvertising(AdvContract contract)
        {
            var file = ConfigurationManager.AppSettings["fileAdv"];

            var document = XDocument.Load(file);

            document.Root.Add(new XElement("AdvModel", new XAttribute("Id", contract.Id), new XElement("Message", contract.Message)));

            document.Save(file);
        }
    }
}
