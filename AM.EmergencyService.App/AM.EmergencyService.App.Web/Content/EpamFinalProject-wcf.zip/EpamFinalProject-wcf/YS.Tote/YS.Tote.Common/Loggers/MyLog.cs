﻿using log4net;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace YS.Tote.Common.Loggers
{
    public class MyLog : IMyLog
    {
        private readonly ILog _log;

        public MyLog()
        {
            string fileName = @"\Log.config";

            string path = new DirectoryInfo(Path.GetDirectoryName(new Uri(Assembly.GetExecutingAssembly().CodeBase).LocalPath)).FullName;
            //string path2 = @"D:\Git\Repositories\EpamFinalProject\YS.Tote\YS.Tote.Common\bin\Debug";
            //string path = Environment.CurrentDirectory;

            //var filInfo2 = new FileInfo(path2 + fileName);
            var fileInfo = new FileInfo(path + fileName);

            if (fileInfo.Exists)
            {
                XmlConfigurator.Configure(fileInfo);

                _log = LogManager.GetLogger("LoggerName");
            }
        }

        public void Info(string info)
        {
            _log.Info(info);
        }
    }
}
