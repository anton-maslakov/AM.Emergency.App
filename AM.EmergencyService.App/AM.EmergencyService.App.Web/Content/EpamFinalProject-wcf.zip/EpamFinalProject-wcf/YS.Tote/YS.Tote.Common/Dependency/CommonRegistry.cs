﻿using StructureMap.Configuration.DSL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.Common.Loggers;

namespace YS.Tote.Common.Dependency
{
    public class CommonRegistry : Registry
    {
        public CommonRegistry()
        {
            ForSingletonOf<IMyLog>().Use<MyLog>();
        }
    }
}
