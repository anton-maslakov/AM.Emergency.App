﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YS.Tote.Common.EntityModels
{
    public class TeamModel
    {
        public int Id { get; set; }
        public string TeamName { get; set; }
        public string TeamContry { get; set; }
    }
}
