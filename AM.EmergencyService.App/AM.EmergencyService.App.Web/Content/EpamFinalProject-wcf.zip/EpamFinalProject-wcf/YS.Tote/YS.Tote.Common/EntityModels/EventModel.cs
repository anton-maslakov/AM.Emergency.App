﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YS.Tote.Common.EntityModels
{
    public class EventModel
    {
        public int Id { get; set; }
        public string EventName { get; set; }
        public DateTime EventDate { get; set; }
        public int FirstTeamId { get; set; }
        public int SecondTeamId { get; set; }
        public string KindOfSport { get; set; }
        public string EventStatus { get; set; }
    }
}
