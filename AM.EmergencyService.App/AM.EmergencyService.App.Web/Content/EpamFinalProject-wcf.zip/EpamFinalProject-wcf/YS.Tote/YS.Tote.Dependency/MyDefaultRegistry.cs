﻿using StructureMap.Configuration.DSL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.BusinessLogic.Dependency;
using YS.Tote.Common.Dependency;
using YS.Tote.DataAccess.Dependency;
using YS.Tote.WCF.Dependency;

namespace YS.Tote.Dependency
{
    public class MyDefaultRegistry : Registry
    {
        public MyDefaultRegistry()
        {
            Scan(m =>
            {
                m.AssemblyContainingType<BusinessRegistry>();
                m.AssemblyContainingType<CommonRegistry>();
                m.AssemblyContainingType<DataRegistry>();
                m.AssemblyContainingType<WCFRegistry>();

                m.WithDefaultConventions();
                m.LookForRegistries();
            });
        }
    }
}
