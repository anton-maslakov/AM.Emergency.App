﻿using StructureMap.Configuration.DSL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.DataAccess.Abstract;
using YS.Tote.DataAccess.Components;

namespace YS.Tote.DataAccess.Dependency
{
    public class DataRegistry : Registry
    {
        public DataRegistry()
        {
            For<IAdvertisingComponent>().Use<AdvertisingComponent>();
            For<IEventComponent>().Use<EventComponent>();
            For<ISportComponent>().Use<SportComponent>();
            For<ITeamComponent>().Use<TeamComponent>();
        }
    }
}
