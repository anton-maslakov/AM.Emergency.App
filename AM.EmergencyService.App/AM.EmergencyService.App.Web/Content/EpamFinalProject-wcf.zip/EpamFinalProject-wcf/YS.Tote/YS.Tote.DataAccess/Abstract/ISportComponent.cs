﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.Common.EntityModels;

namespace YS.Tote.DataAccess.Abstract
{
    public interface ISportComponent
    {
        void Create(SportModel contract);

        void Update(SportModel contract);

        void Delete(int? id);

        SportModel SelectById(int? id);

        IEnumerable<SportModel> SelectAll();

        SportModel SelectByName(string sportName);
    }
}
