﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.Common.EntityModels;

namespace YS.Tote.DataAccess.Abstract
{
    public interface IAdvertisingComponent
    {
        AdvModel SelectAdvertising(int? id);

        void Create(AdvModel contract);
    }
}
