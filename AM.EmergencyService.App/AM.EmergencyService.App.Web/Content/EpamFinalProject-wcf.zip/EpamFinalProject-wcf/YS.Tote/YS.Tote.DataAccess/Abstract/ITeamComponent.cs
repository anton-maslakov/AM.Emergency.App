﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.Common.EntityModels;

namespace YS.Tote.DataAccess.Abstract
{
    public interface ITeamComponent
    {
        void Create(TeamModel model);

        void Update(TeamModel model);

        void Delete(int? id);

        TeamModel SelectById(int? id);

        IEnumerable<TeamModel> SelectAll();

        TeamModel SelectByName(string teamName);

        TeamModel SelectByCountry(string countryName);
    }
}
