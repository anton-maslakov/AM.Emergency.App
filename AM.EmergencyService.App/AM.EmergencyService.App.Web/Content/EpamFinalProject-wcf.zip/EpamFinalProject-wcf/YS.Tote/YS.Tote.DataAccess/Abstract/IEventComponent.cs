﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.Common.EntityModels;

namespace YS.Tote.DataAccess.Abstract
{
    public interface IEventComponent
    {
        void Create(EventModel contract);

        void Update(EventModel contract);

        void Delete(int? id);

        IEnumerable<EventModel> SelectAll();

        EventModel SelectById(int? id);

        EventModel SelectByName(string eventName);

        EventModel SelectEventByDate(DateTime eventDate);

        EventModel SelectEventByKindOfSport(string sportName);

        EventModel SelectEventByStatus(string eventStatus);
    }
}
