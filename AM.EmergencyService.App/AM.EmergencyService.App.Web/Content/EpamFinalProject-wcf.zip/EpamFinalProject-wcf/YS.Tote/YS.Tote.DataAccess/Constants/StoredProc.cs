﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;

namespace YS.Tote.DataAccess.Constants
{
    public class StoredProc
    {
        public const string CreateEvent = "CreateEvent";
        public const string CreateSport = "CreateSport";
        public const string CreateTeam = "CreateTeam";
        public const string CreateAdv = "CreateAdv";

        public const string DeleteEvent = "DeleteEvent";
        public const string DeleteSport = "DeleteSport";
        public const string DeleteTeam = "DeleteTeam";//

        public const string SelectAllAdv = "SelectAllAdv";
        public const string SelectAllEvents = "SelectAllEvents";
        public const string SelectAllSports = "SelectAllSports";
        public const string SelectAllTeams = "SelectAllTeams";
        public const string SelectEventByDate = "SelectEventByDate";
        public const string SelectEventById = "SelectEventById";
        public const string SelectEventByKindOfSport = "SelectEventByKindOfSport";
        public const string SelectEventByStatus = "SelectEventByStatus";
        public const string SelectEventByName = "SelectEventByName";//
        public const string SelectSportById = "SelectSportById";
        public const string SelectSportByName = "SelectSportByName";//
        public const string SelectTeamByCountry = "SelectTeamByCountry";
        public const string SelectTeamById = "SelectTeamById";
        public const string SelectTeamByName = "SelectTeamByName";

        public const string UpdateEvent = "UpdateEvent";
        public const string UpdateTeam = "UpdateTeam";
        public const string UpdateSport = "UpdateSport";//

        public static string ConnectionString = ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;
    }
}
