﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.Common.EntityModels;
using YS.Tote.DataAccess.Abstract;
using YS.Tote.DataAccess.Constants;

namespace YS.Tote.DataAccess.Components
{
    public class TeamComponent : ITeamComponent
    {
        public void Create(TeamModel contract)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.CreateTeam, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter() { ParameterName = "@TeamName", Value = contract.TeamName },
                    new SqlParameter(){ ParameterName = "@TeamCountry", Value = contract.TeamContry }
                };

                command.Parameters.AddRange(parameters);
            }
        }

        public void Delete(int? id)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.DeleteTeam, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter() { ParameterName = "@Id", Value = id },
                };

                command.Parameters.AddRange(parameters);
            }
        }

        public IEnumerable<TeamModel> SelectAll()
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.SelectAllTeams, connection) { CommandType = CommandType.StoredProcedure };

                var reader = command.ExecuteReader();

                List<TeamModel> contract = new List<TeamModel>();

                while (reader.Read())
                {
                    contract.Add(new TeamModel
                    {
                        Id = (int)reader["Id"],
                        TeamContry = (string)reader["TeamContry"],
                        TeamName = (string)reader["TeamName"]
                    });
                }

                return contract;
            }
        }

        public TeamModel SelectByCountry(string countryName)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.SelectTeamByCountry, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter(){ ParameterName = "@TeamCountry", Value = countryName }
                };

                command.Parameters.AddRange(parameters);

                var reader = command.ExecuteReader();

                TeamModel contract = null;

                if (reader.Read())
                {
                    contract = new TeamModel()
                    {
                        Id = (int)reader["Id"],
                        TeamContry = (string)reader["TeamCountry"],
                        TeamName = (string)reader["TeamName"]
                    };
                }

                return contract;
            }
        }

        public TeamModel SelectById(int? id)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.SelectTeamById, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter(){ ParameterName = "@Id", Value = id }
                };

                command.Parameters.AddRange(parameters);

                var reader = command.ExecuteReader();

                TeamModel contract = null;

                if (reader.Read())
                {
                    contract = new TeamModel()
                    {
                        Id = (int)reader["Id"],
                        TeamContry = (string)reader["TeamCountry"],
                        TeamName = (string)reader["TeamName"]
                    };
                }

                return contract;
            }
        }

        public TeamModel SelectByName(string teamName)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.SelectTeamByName, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter(){ ParameterName = "@TeamName", Value = teamName }
                };

                command.Parameters.AddRange(parameters);

                var reader = command.ExecuteReader();

                TeamModel contract = null;

                if (reader.Read())
                {
                    contract = new TeamModel()
                    {
                        Id = (int)reader["Id"],
                        TeamContry = (string)reader["TeamCountry"],
                        TeamName = (string)reader["TeamName"]
                    };
                }

                return contract;
            }
        }

        public void Update(TeamModel contract)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.UpdateTeam, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter() { ParameterName = "@Id", Value = contract.Id },
                    new SqlParameter() { ParameterName = "@TeamName", Value = contract.TeamName },
                    new SqlParameter(){ ParameterName = "@TeamCountry", Value = contract.TeamContry }
                };

                command.Parameters.AddRange(parameters);
            }
        }
    }
}
