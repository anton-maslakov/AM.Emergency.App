﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.Common.EntityModels;
using YS.Tote.DataAccess.Abstract;
using YS.Tote.DataAccess.Constants;

namespace YS.Tote.DataAccess.Components
{
    public class EventComponent : IEventComponent
    {
        public void Create(EventModel contract)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.CreateEvent, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter() { ParameterName = "@EventDate", Value = contract.EventDate },
                    new SqlParameter(){ ParameterName = "@EventName", Value = contract.EventName },
                    new SqlParameter() { ParameterName = "@EventStatus", Value = contract.EventStatus },
                    new SqlParameter() { ParameterName = "@FirstTeamId", Value = contract.FirstTeamId },
                    new SqlParameter() { ParameterName = "@SecondTeamId", Value = contract.SecondTeamId },
                    new SqlParameter() { ParameterName = "@KindOfSport", Value = contract.KindOfSport }
                };

                command.Parameters.AddRange(parameters);
            }
        }

        public void Delete(int? id)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.DeleteEvent, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter() { ParameterName = "@Id", Value = id }
                };

                command.Parameters.AddRange(parameters);
            }
        }

        public IEnumerable<EventModel> SelectAll()
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.SelectAllEvents, connection) { CommandType = CommandType.StoredProcedure };

                var reader = command.ExecuteReader();

                List<EventModel> contract = new List<EventModel>();

                while (reader.Read())
                {
                    contract.Add(new EventModel
                    {
                        Id = (int)reader["Id"],
                        EventDate = (DateTime)reader["EventDate"],
                        EventName = (string)reader["EventName"],
                        EventStatus = (string)reader["EventStatus"],
                        FirstTeamId = (int)reader["FirstTeamId"],
                        SecondTeamId = (int)reader["SecondTeamId"],
                        KindOfSport = (string)reader["KindOfSport"]
                    });
                }

                return contract;
            }
        }

        public EventModel SelectById(int? id)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.SelectEventById, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter() { ParameterName = "@Id", Value = id },
                };

                command.Parameters.AddRange(parameters);

                var reader = command.ExecuteReader();

                EventModel contract = null;

                if (reader.Read())
                {
                    contract = new EventModel()
                    {
                        Id = (int)reader["Id"],
                        EventDate = (DateTime)reader["EventDate"],
                        EventName = (string)reader["EventName"],
                        EventStatus = (string)reader["EventStatus"],
                        FirstTeamId = (int)reader["FirstTeamId"],
                        SecondTeamId = (int)reader["SecondTeamId"],
                        KindOfSport = (string)reader["KindOfSport"]
                    };
                }

                return contract;
            }
        }

        public EventModel SelectByName(string eventName)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.SelectEventByName, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter() { ParameterName = "@EventName", Value = eventName },
                };

                command.Parameters.AddRange(parameters);

                var reader = command.ExecuteReader();

                EventModel contract = null;

                if (reader.Read())
                {
                    contract = new EventModel()
                    {
                        Id = (int)reader["Id"],
                        EventDate = (DateTime)reader["EventDate"],
                        EventName = (string)reader["EventName"],
                        EventStatus = (string)reader["EventStatus"],
                        FirstTeamId = (int)reader["FirstTeamId"],
                        SecondTeamId = (int)reader["SecondTeamId"],
                        KindOfSport = (string)reader["KindOfSport"]
                    };
                }

                return contract;
            }
        }

        public EventModel SelectEventByDate(DateTime eventDate)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.SelectEventByDate, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter() { ParameterName = "@EventDate", Value = eventDate },
                };

                command.Parameters.AddRange(parameters);

                var reader = command.ExecuteReader();

                EventModel contract = null;

                if (reader.Read())
                {
                    contract = new EventModel()
                    {
                        Id = (int)reader["Id"],
                        EventDate = (DateTime)reader["EventDate"],
                        EventName = (string)reader["EventName"],
                        EventStatus = (string)reader["EventStatus"],
                        FirstTeamId = (int)reader["FirstTeamId"],
                        SecondTeamId = (int)reader["SecondTeamId"],
                        KindOfSport = (string)reader["KindOfSport"]
                    };
                }

                return contract;
            }
        }

        public EventModel SelectEventByKindOfSport(string sportName)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.SelectEventByKindOfSport, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter() { ParameterName = "@KindOfSport", Value = sportName },
                };

                command.Parameters.AddRange(parameters);

                var reader = command.ExecuteReader();

                EventModel contract = null;

                if (reader.Read())
                {
                    contract = new EventModel()
                    {
                        Id = (int)reader["Id"],
                        EventDate = (DateTime)reader["EventDate"],
                        EventName = (string)reader["EventName"],
                        EventStatus = (string)reader["EventStatus"],
                        FirstTeamId = (int)reader["FirstTeamId"],
                        SecondTeamId = (int)reader["SecondTeamId"],
                        KindOfSport = (string)reader["KindOfSport"]
                    };
                }

                return contract;
            }
        }

        public EventModel SelectEventByStatus(string eventStatus)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.SelectEventByStatus, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter() { ParameterName = "@EventStatus", Value = eventStatus },
                };

                command.Parameters.AddRange(parameters);

                var reader = command.ExecuteReader();

                EventModel contract = null;

                if (reader.Read())
                {
                    contract = new EventModel()
                    {
                        Id = (int)reader["Id"],
                        EventDate = (DateTime)reader["EventDate"],
                        EventName = (string)reader["EventName"],
                        EventStatus = (string)reader["EventStatus"],
                        FirstTeamId = (int)reader["FirstTeamId"],
                        SecondTeamId = (int)reader["SecondTeamId"],
                        KindOfSport = (string)reader["KindOfSport"]
                    };
                }

                return contract;
            }
        }

        public void Update(EventModel contract)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.UpdateEvent, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter() { ParameterName = "@Id", Value = contract.Id },
                    new SqlParameter() { ParameterName = "@EventDate", Value = contract.EventDate },
                    new SqlParameter(){ ParameterName = "@EventName", Value = contract.EventName },
                    new SqlParameter() { ParameterName = "@EventStatus", Value = contract.EventStatus }
                };

                command.Parameters.AddRange(parameters);
            }
        }
    }
}
