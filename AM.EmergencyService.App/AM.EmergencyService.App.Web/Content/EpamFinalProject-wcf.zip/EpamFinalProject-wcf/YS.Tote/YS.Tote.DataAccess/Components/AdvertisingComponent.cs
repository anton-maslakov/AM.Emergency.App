﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.Common.EntityModels;
using YS.Tote.DataAccess.Abstract;
using YS.Tote.DataAccess.Constants;
using YS.Tote.DataAccess.MyWCF;
using YS.Tote.WCF;

namespace YS.Tote.DataAccess.Components
{
    public class AdvertisingComponent : IAdvertisingComponent
    {
        private AdvertisingServiceClient _client = new AdvertisingServiceClient("BasicHttpBinding_IAdvertisingService");

        public AdvModel SelectAdvertising(int? id)
        {
            var contract = _client.GetAdvertising(id);

            var model = new AdvModel() { Id = contract.Id, Message = contract.Message };

            return model;
        }

        private IEnumerable<AdvModel> SelectAllAdv()
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.SelectAllAdv, connection) { CommandType = CommandType.StoredProcedure };

                var reader = command.ExecuteReader();

                List<AdvModel> contract = new List<AdvModel>();

                while (reader.Read())
                {
                    contract.Add(new AdvModel
                    {
                        Id = (int)reader["Id"],
                        Message = (string)reader["Message"]
                    });
                }

                return contract;
            }
        }

        private void SetAdv()
        {
            var list = SelectAllAdv();

            foreach (var item in list)
            {
                _client.SetAdvertising(new MyWCF.AdvContract { Id = item.Id, Message = item.Message });
            }
        }

        public void Create(AdvModel contract)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.CreateAdv, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter() { ParameterName = "@Message", Value = contract.Message }
                };

                command.Parameters.AddRange(parameters);
            }
        }
    }
}
