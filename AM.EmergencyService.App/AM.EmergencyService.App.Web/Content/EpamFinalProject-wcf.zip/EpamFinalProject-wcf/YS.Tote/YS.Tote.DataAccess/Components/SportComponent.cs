﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YS.Tote.Common.EntityModels;
using YS.Tote.DataAccess.Abstract;
using YS.Tote.DataAccess.Constants;

namespace YS.Tote.DataAccess.Components
{
    public class SportComponent : ISportComponent
    {
        public void Create(SportModel contract)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.CreateSport, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter() { ParameterName = "@KindOfSport", Value = contract.SportName }
                };

                command.Parameters.AddRange(parameters);
            }
        }

        public void Delete(int? id)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.DeleteSport, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter() { ParameterName = "@Id", Value = id }
                };

                command.Parameters.AddRange(parameters);
            }
        }

        public IEnumerable<SportModel> SelectAll()
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.SelectAllSports, connection) { CommandType = CommandType.StoredProcedure };

                var reader = command.ExecuteReader();

                List<SportModel> contract = new List<SportModel>();

                while (reader.Read())
                {
                    contract.Add(new SportModel
                    {
                        Id = (int)reader["Id"],
                        SportName = (string)reader["SportName"]
                    });
                }

                return contract;
            }
        }

        public SportModel SelectById(int? id)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.SelectSportById, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter(){ ParameterName = "@Id", Value = id }
                };

                command.Parameters.AddRange(parameters);

                var reader = command.ExecuteReader();

                SportModel contract = null;

                if (reader.Read())
                {
                    contract = new SportModel()
                    {
                        Id = (int)reader["Id"],
                        SportName = (string)reader["SportName"]
                    };
                }

                return contract;
            }
        }

        public SportModel SelectByName(string sportName)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.SelectSportByName, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter(){ ParameterName = "@KindOfSport", Value = sportName }
                };

                command.Parameters.AddRange(parameters);

                var reader = command.ExecuteReader();

                SportModel contract = null;

                if (reader.Read())
                {
                    contract = new SportModel()
                    {
                        Id = (int)reader["Id"],
                        SportName = (string)reader["SportName"]
                    };
                }

                return contract;
            }
        }

        public void Update(SportModel contract)
        {
            using (var connection = new SqlConnection(StoredProc.ConnectionString))
            {
                connection.Open();

                var command = new SqlCommand(StoredProc.UpdateSport, connection) { CommandType = CommandType.StoredProcedure };

                SqlParameter[] parameters = {
                    new SqlParameter() { ParameterName = "@Id", Value = contract.Id },
                    new SqlParameter() { ParameterName = "@KindOfSport", Value = contract.SportName }
                };

                command.Parameters.AddRange(parameters);
            }
        }
    }
}
